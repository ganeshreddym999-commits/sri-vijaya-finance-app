# Sri Vijaya Lakshmi Agencies — Finance App Starter

A responsive, installable-web-app prototype for a small finance/loan-management business.

## Included in this starter
- Customer records (name, phone, village/location, notes)
- Loan records and configurable rate per ₹100 per week
- Dashboard with principal and estimated interest outstanding
- Payment history
- Printable payment receipts
- CSV payment export and JSON backup
- Responsive layout for mobile and desktop
- Basic PWA files for installability/offline shell

## Important limitations — read before real use
This is a **prototype**, not a secure production finance system.
- Login is only a demo role selector. It does not verify identity or passwords.
- Data is saved in this browser's localStorage and does not sync across devices.
- Anyone using the same browser profile may be able to access its data.
- Do not enter real customer phone numbers, addresses, identity documents, or financial records yet.
- The prototype does not provide tamper-proof audit logs, secure multi-user permissions, cloud backup, or legally validated interest/collection calculations.
- The "mixed" payment type does not automatically split a payment between interest and principal. Record separate payments or add a verified split workflow before real use.
- Closing a loan is a manual status change and does not independently verify that all dues are paid.
- Interest estimates are simple estimates based on the current principal, entered weekly rate, and elapsed time. Real calculations must follow the signed agreement and applicable law.

## Run it on your computer for free
### Easiest option
1. Extract the ZIP file.
2. Open the folder.
3. Double-click `index.html` to open it in a browser.
4. Choose Admin / Owner and click **Open dashboard**.
5. Try **Load fictional sample data**. Use fictional information only.
6. Add a customer, record a loan, add a payment, and print a receipt.

Some browser features (PWA installation/offline caching) need the app to be served over `localhost` or HTTPS, rather than opened as a file.

### Optional local server
If Python is installed:
1. Open a terminal/Command Prompt in this folder.
2. Run `python -m http.server 8000`
3. In your browser open `http://localhost:8000`

Stop the server with Ctrl+C.

## Install on phone
For installation, the app must be hosted on HTTPS. A free static host can serve the prototype, but hosting it does **not** make the localStorage data sync between devices. Each browser has its own separate data.

## Next steps before using real customer data
1. Set up Firebase Authentication.
2. Use Cloud Firestore for customers, loans, payments, and receipt records.
3. Enforce role-based access with Firestore Security Rules (admin-only writes; a customer can read only their own records).
4. Add a verified interest calculation policy, principal/interest allocation, audit history, consent/privacy notices, secure backups, and recovery.
5. Test with fictional records and have the loan terms reviewed for applicable local requirements.

Never deploy with public database rules such as `allow read, write: if true`.
