/* Demo-only browser prototype. Not secure production authentication/storage. */
const DB_KEY = "svla_finance_demo_v1";
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let db = loadDB();
let currentRole = "admin";
let currentName = "Owner";
let installPrompt = null;

function loadDB(){
  try { return JSON.parse(localStorage.getItem(DB_KEY)) || {customers:[],loans:[],payments:[]}; }
  catch { return {customers:[],loans:[],payments:[]}; }
}
function saveDB(){ localStorage.setItem(DB_KEY, JSON.stringify(db)); renderAll(); }
function id(){ return (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`); }
function today(){ return new Date().toISOString().slice(0,10); }
function money(n){ return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(n)||0); }
function esc(v){ return String(v ?? "").replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function toast(msg){ const el=$("#toast"); el.textContent=msg; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2600); }
function customer(id){ return db.customers.find(c=>c.id===id); }
function loan(id){ return db.loans.find(l=>l.id===id); }
function paymentsFor(loanId){ return db.payments.filter(p=>p.loanId===loanId); }
function principalPaid(l){ return paymentsFor(l.id).filter(p=>p.kind==="principal"||p.kind==="mixed").reduce((s,p)=>s+Number(p.principalPart||0),0); }
function principalOutstanding(l){ return Math.max(0, Number(l.principal)-principalPaid(l)); }
function weeksElapsed(start, end=today()){
  const a = new Date(`${start}T00:00:00`), b = new Date(`${end}T00:00:00`);
  return Math.max(0,(b-a)/(7*86400000));
}
function interestAccrued(l, end=today()){
  const rate = Number(l.rate)/100; // ₹ per ₹100 per week; default 2 means 2% weekly
  const weeks = weeksElapsed(l.startDate,end);
  const multiplier = l.frequency==="monthly" ? 1 : 1;
  // Interest-only simple estimate on current principal; fractional weeks are prorated.
  // Monthly dues are displayed as 52/12 weeks per month elsewhere; accrual stays weekly.
  return principalOutstanding(l) * rate * weeks * multiplier;
}
function interestPaid(l){ return paymentsFor(l.id).filter(p=>p.kind==="interest").reduce((s,p)=>s+Number(p.amount),0); }
function interestOutstanding(l){ return Math.max(0,interestAccrued(l)-interestPaid(l)); }
function totalPaid(l){ return paymentsFor(l.id).reduce((s,p)=>s+Number(p.amount),0); }
function setOptions(select, items, firstLabel){
  const old = select.value;
  select.innerHTML = `<option value="">${esc(firstLabel)}</option>`+items.map(x=>`<option value="${esc(x.value)}">${esc(x.label)}</option>`).join("");
  if(items.some(x=>x.value===old)) select.value=old;
}
function table(headers, rows){
  if(!rows.length) return '<div class="empty">No records yet.</div>';
  return `<table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
}
function renderAll(){
  $("#statCustomers").textContent=db.customers.length;
  $("#statLoans").textContent=db.loans.filter(l=>!l.closed).length;
  $("#statPrincipal").textContent=money(db.loans.filter(l=>!l.closed).reduce((s,l)=>s+principalOutstanding(l),0));
  $("#statInterest").textContent=money(db.loans.filter(l=>!l.closed).reduce((s,l)=>s+interestOutstanding(l),0));
  $("#customerList").innerHTML=table(["Name","Phone","Village / location","Notes"],db.customers.map(c=>[esc(c.name),esc(c.phone||"—"),esc(c.location||"—"),esc(c.notes||"—")]));
  setOptions($("#loanCustomer"),db.customers.map(c=>({value:c.id,label:`${c.name}${c.location?" — "+c.location:""}`})),"Choose customer");
  setOptions($("#paymentLoan"),db.loans.filter(l=>!l.closed).map(l=>({value:l.id,label:`${customer(l.customerId)?.name||"Unknown"} — ${money(l.principal)} loan`})),"Choose loan");
  $("#loanList").innerHTML=table(["Customer","Principal","Start date","Rate / week","Principal due","Interest due*","Frequency","Action"],db.loans.map(l=>[
    esc(customer(l.customerId)?.name||"Unknown"),money(l.principal),esc(l.startDate),`${money(l.rate)} per ₹100`,money(principalOutstanding(l)),money(interestOutstanding(l)),esc(l.frequency),
    `<button class="small-action secondary" data-close="${l.id}">${l.closed?"Reopen":"Mark closed"}</button>`
  ]));
  $("#paymentList").innerHTML=table(["Date","Receipt","Customer","Amount","Applied to","Method","Note"],[...db.payments].sort((a,b)=>b.date.localeCompare(a.date)).map(p=>[
    esc(p.date),esc(p.receipt),esc(customer(loan(p.loanId)?.customerId)?.name||"Unknown"),money(p.amount),esc(p.kind),esc(p.method),esc(p.note||"")
  ]));
  const recent=[...db.payments].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
  $("#recentPayments").innerHTML=table(["Date","Receipt","Customer","Amount"],recent.map(p=>[esc(p.date),esc(p.receipt),esc(customer(loan(p.loanId)?.customerId)?.name||"Unknown"),money(p.amount)]));
  $("#reportSummary").innerHTML=`<p><strong>Total customers:</strong> ${db.customers.length}</p>
    <p><strong>Total loans recorded:</strong> ${db.loans.length}</p>
    <p><strong>Total payments recorded:</strong> ${money(db.payments.reduce((s,p)=>s+Number(p.amount),0))}</p>
    <p><strong>Principal outstanding:</strong> ${money(db.loans.filter(l=>!l.closed).reduce((s,l)=>s+principalOutstanding(l),0))}</p>
    <p><strong>Estimated interest outstanding:</strong> ${money(db.loans.filter(l=>!l.closed).reduce((s,l)=>s+interestOutstanding(l),0))}</p>
    <p class="small muted">*Estimate uses the entered weekly rate and elapsed time. It is not a legal statement or a substitute for checking the agreement.</p>`;
  $$("[data-close]").forEach(b=>b.addEventListener("click",()=>{
    const l=loan(b.dataset.close); if(!l)return;
    l.closed=!l.closed; saveDB(); toast(l.closed?"Loan marked closed":"Loan reopened");
  }));
}
function showTab(tab){
  $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  $$(".tab-content").forEach(s=>s.classList.toggle("hidden",s.id!==`tab-${tab}`));
}
function openApp(){
  currentRole=$("#roleSelect").value; currentName=$("#loginName").value.trim()||"User";
  $("#loginPanel").classList.add("hidden"); $("#appPanel").classList.remove("hidden");
  $("#welcomeTitle").textContent=`Welcome, ${currentName}`;
  $("#roleCaption").textContent=currentRole==="admin"?"Admin demo view":"Customer demo view — records are not linked to a real customer account";
  $$(".admin-only").forEach(el=>el.classList.toggle("hidden",currentRole!=="admin"));
  showTab("dashboard"); renderAll();
}
$("#loginBtn").addEventListener("click",openApp);
$("#logoutBtn").addEventListener("click",()=>{$("#appPanel").classList.add("hidden");$("#loginPanel").classList.remove("hidden");});
$$(".tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));
$("#customerForm").addEventListener("submit",e=>{
  e.preventDefault(); const f=new FormData(e.target);
  db.customers.push({id:id(),name:f.get("name").trim(),phone:f.get("phone").trim(),location:f.get("location").trim(),notes:f.get("notes").trim()});
  saveDB(); e.target.reset(); toast("Customer saved");
});
$("#loanForm").addEventListener("submit",e=>{
  e.preventDefault(); const f=new FormData(e.target);
  const principal=Number(f.get("principal")), rate=Number(f.get("rate"));
  if(!f.get("customerId")||principal<=0||rate<0){toast("Check customer, amount and rate");return;}
  db.loans.push({id:id(),customerId:f.get("customerId"),principal,startDate:f.get("startDate"),rate,frequency:f.get("frequency"),principalPlan:f.get("principalPlan"),note:f.get("note").trim(),closed:false});
  saveDB(); e.target.reset(); e.target.elements.rate.value="2"; e.target.elements.startDate.value=today(); toast("Loan saved");
});
$("#paymentForm").addEventListener("submit",e=>{
  e.preventDefault(); const f=new FormData(e.target); const l=loan(f.get("loanId")); const amount=Number(f.get("amount"));
  if(!l||amount<=0){toast("Choose a loan and valid amount");return;}
  const kind=f.get("kind");
  // In this prototype, interest payments reduce estimated interest due; principal payments reduce principal.
  // Mixed payments require a principal split to be recorded, so default split is zero and the note should explain it.
  const principalPart=kind==="principal"?amount:(kind==="mixed"?0:0);
  const p={id:id(),loanId:l.id,date:f.get("date"),amount,kind,principalPart,method:f.get("method"),note:f.get("note").trim(),receipt:`SVLA-${Date.now().toString().slice(-8)}`};
  db.payments.push(p); saveDB(); e.target.reset(); e.target.elements.date.value=today();
  showReceipt(p); toast("Payment saved. Receipt opened for printing.");
});
function showReceipt(p){
  const l=loan(p.loanId), c=customer(l?.customerId);
  const w=window.open("","_blank","width=650,height=700");
  if(!w){toast("Allow pop-ups to print the receipt");return;}
  w.document.write(`<!doctype html><html><head><title>Receipt ${esc(p.receipt)}</title><style>body{font:16px Arial;padding:32px;color:#222}.box{border:1px solid #aaa;padding:24px;max-width:520px;margin:auto}h1{font-size:22px}hr{margin:20px 0}small{color:#666}</style></head><body><div class="box"><h1>Sri Vijaya Lakshmi Agencies</h1><h2>Payment Receipt</h2><hr><p><b>Receipt No:</b> ${esc(p.receipt)}</p><p><b>Date:</b> ${esc(p.date)}</p><p><b>Received from:</b> ${esc(c?.name||"Unknown customer")}</p><p><b>Loan principal:</b> ${money(l?.principal)}</p><p><b>Amount received:</b> <b>${money(p.amount)}</b></p><p><b>Applied to:</b> ${esc(p.kind)}</p><p><b>Payment method:</b> ${esc(p.method)}</p><p><b>Note:</b> ${esc(p.note||"—")}</p><hr><small>Generated by a demo prototype. Please verify the payment and balances against the signed agreement and business records.</small><p><button onclick="window.print()">Print / Save PDF</button></p></div></body></html>`);
  w.document.close();
}
function download(filename,content,type="application/json"){
  const blob=new Blob([content],{type}), url=URL.createObjectURL(blob), a=document.createElement("a");
  a.href=url;a.download=filename;a.click();URL.revokeObjectURL(url);
}
function exportBackup(){download(`svla-backup-${today()}.json`,JSON.stringify(db,null,2));}
$("#exportBtn").addEventListener("click",exportBackup);
$("#downloadBackupBtn").addEventListener("click",exportBackup);
$("#exportPaymentsBtn").addEventListener("click",()=>{
  const rows=[["Date","Receipt","Customer","Amount","Type","Method","Note"],...db.payments.map(p=>[p.date,p.receipt,customer(loan(p.loanId)?.customerId)?.name||"",p.amount,p.kind,p.method,p.note||""])];
  const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
  download(`svla-payments-${today()}.csv`,csv,"text/csv;charset=utf-8");
});
$("#printReportBtn").addEventListener("click",()=>window.print());
$("#today").textContent=new Date().toLocaleDateString("en-IN",{dateStyle:"medium"});
$("#loanForm").elements.startDate.value=today();
$("#paymentForm").elements.date.value=today();
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("#installBtn").classList.remove("hidden");});
$("#installBtn").addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("#installBtn").classList.add("hidden");});

// Optional demo records: click the message below only when you want sample data.
if(!localStorage.getItem(DB_KEY)){
  const demoButton=document.createElement("button");demoButton.className="secondary";demoButton.textContent="Load fictional sample data";
  demoButton.addEventListener("click",()=>{
    const cid=id(), lid=id();
    db={customers:[{id:cid,name:"Demo Customer",phone:"",location:"Sample Village",notes:"Fictional sample only"}],
      loans:[{id:lid,customerId:cid,principal:50000,startDate:today(),rate:2,frequency:"weekly",principalPlan:"separate",note:"Illustrative only",closed:false}],payments:[]};
    saveDB();toast("Fictional sample data loaded");
  });
  $("#loginPanel").appendChild(demoButton);
}
