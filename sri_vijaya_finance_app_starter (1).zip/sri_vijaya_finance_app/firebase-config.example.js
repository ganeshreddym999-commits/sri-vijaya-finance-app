/*
Firebase is NOT connected in this starter.
When you are ready:
1. Create a Firebase project and enable Authentication + Firestore.
2. Use Firebase Authentication (email/password or phone OTP).
3. Create Firestore Security Rules that enforce admin/customer access on the server.
4. Replace this example with your project's Firebase web configuration.
Do not put service-account/private admin keys in browser code.
*/
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
